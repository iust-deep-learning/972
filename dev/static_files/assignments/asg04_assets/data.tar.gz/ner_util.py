import sys
from collections import Counter
from keras.utils import to_categorical
import matplotlib.pyplot as plt
import numpy as np

PAD_TOK = '<pad>'
START_TOK = '<s>'
END_TOK = '</s>'
UNK_TOK = '<unk>'
NUM_TOK = '<num>'

special_toks = [PAD_TOK, START_TOK, END_TOK, UNK_TOK, NUM_TOK]
LBLS = [
    "PER",
    "ORG",
    "LOC",
    "MISC",
    "O",
    ]
NONE = "O"
LMAP = {k: i for i, k in enumerate(LBLS)}

def read_split(fname):
  with open(fname, encoding='utf8') as f:
    split = []
    for l in f:
      l = l.strip()
      toks,lbls = l.split('\t')
      toks = toks.split(' ')
      lbls = lbls.split(' ')
      split.append((toks, lbls))
      
  return split 

def create_vocab(lst_sent, vocab_size):
  c = Counter()
  for toks in lst_sent:
    c.update([t.lower() for t in toks])
  
  words = [w for w,_ in c.most_common(vocab_size)] 
  vocab = special_toks + words
  
  return vocab

def read_dataset(vocab_size):  
  train = read_split('train.tsv')
  valid = read_split('valid.tsv')
  
  vocab = create_vocab([s for s,_ in train], vocab_size)
  return train, valid, vocab

def window_iterator(seq, n=1):
	"""Credits: Stanford CS224d course"""
    for i in range(len(seq)):
      l = max(0, i-n)
      r = min(len(seq), i+n+1)
      ret = seq[l:r]
      if i < n:
        ret = [START_TOK,] * (n-i) + ret
      if i+n+1 > len(seq):
        ret = ret + [END_TOK,] * (i+n+1 - len(seq))
      yield ret

def convert_to_window_based(data, n=1):
  new_data = []
  for toks, lbls in data:
    windows = list(window_iterator(toks, n))
    assert len(windows) == len(lbls)
    new_data.extend(list(zip(windows, lbls)))
  
  return new_data  


def preprocess(data, tok2id, casing_fn):
  windows, labels = zip(*data)
  features = featurize(windows, tok2id, casing_fn)
  labels = to_categorical([LMAP[l] for l in labels])
  return features, labels

def featurize(windows, tok2id, casing_fn):
  all_tok_ids = []
  all_casings = []
  
  unk_id = tok2id[UNK_TOK]
  for wind in windows:
    tok_ids = []
    casings = []
    for t in wind:
      c = casing_fn(t)
      t = NUM_TOK if t.isdigit() else t.lower()
      
      tok_ids.append(tok2id.get(t, unk_id))
      casings.append(c)
      
    tok_ids = np.array(tok_ids, np.int64)
    casings = np.concatenate(casings, axis=0).astype(np.float32)
    
    all_tok_ids.append(tok_ids)
    all_casings.append(casings)
  
  return (np.array(all_tok_ids), np.array(all_casings))

def visualize_loss_and_acc(history):
  history_dict = history.history
  loss_values = history_dict['loss']
  val_loss_values = history_dict['val_loss']
  acc = history_dict['acc']

  epochs = range(1, len(acc) + 1)

  f = plt.figure(figsize=(10,3))

  plt.subplot(1,2,1)
  plt.plot(epochs, loss_values, 'bo', label='Training loss')
  plt.plot(epochs, val_loss_values, 'b', label='Validation loss')
  plt.title('Training and validation loss')
  plt.xlabel('Epochs')
  plt.ylabel('Loss')
  plt.legend()


  acc_values = history_dict['acc']
  val_acc = history_dict['val_acc']

  plt.subplot(1,2,2)
  plt.plot(epochs, acc, 'bo', label='Training acc')
  plt.plot(epochs, val_acc, 'b', label='Validation acc')
  plt.title('Training and validation accuracy')
  plt.xlabel('Epochs')
  plt.ylabel('Loss')
  plt.legend()

  plt.show()
  
def print_sentence(output, sentence, labels, predictions):
  """Credits: Stanford CS224d course"""
  if labels is None:
    labels_spacing = [""]* len(predictions)
  else:
    labels_spacing = labels
  
  spacings = [max(len(sentence[i]), len(labels_spacing[i]), len(predictions[i])) for i in range(len(sentence))]
  # Compute the word spacing
  output.write("x : ")
  for token, spacing in zip(sentence, spacings):
    output.write(token)
    output.write(" " * (spacing - len(token) + 1))
  output.write("\n")
  
  if labels is not None:
    output.write("y*: ")
    for token, spacing in zip(labels, spacings):
      output.write(token)
      output.write(" " * (spacing - len(token) + 1))
    output.write("\n")

  output.write("y': ")
  for token, spacing in zip(predictions, spacings):
    output.write(token)
    output.write(" " * (spacing - len(token) + 1))
  output.write("\n")
  
def plot_confusion_matrix(cm,
                          target_names,
                          title='Confusion matrix',
                          cmap=None,
                          normalize=True):
    """
    given a sklearn confusion matrix (cm), make a nice plot

    Arguments
    ---------
    cm:           confusion matrix from sklearn.metrics.confusion_matrix

    target_names: given classification classes such as [0, 1, 2]
                  the class names, for example: ['high', 'medium', 'low']

    title:        the text to display at the top of the matrix

    cmap:         the gradient of the values displayed from matplotlib.pyplot.cm
                  see http://matplotlib.org/examples/color/colormaps_reference.html
                  plt.get_cmap('jet') or plt.cm.Blues

    normalize:    If False, plot the raw numbers
                  If True, plot the proportions

    Usage
    -----
    plot_confusion_matrix(cm           = cm,                  # confusion matrix created by
                                                              # sklearn.metrics.confusion_matrix
                          normalize    = True,                # show proportions
                          target_names = y_labels_vals,       # list of names of the classes
                          title        = best_estimator_name) # title of graph

    Citiation
    ---------
    http://scikit-learn.org/stable/auto_examples/model_selection/plot_confusion_matrix.html

    """
    import matplotlib.pyplot as plt
    import numpy as np
    import itertools

    accuracy = np.trace(cm) / float(np.sum(cm))
    misclass = 1 - accuracy

    if cmap is None:
        cmap = plt.get_cmap('Blues')

    plt.figure(figsize=(8, 6))
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()

    if target_names is not None:
        tick_marks = np.arange(len(target_names))
        plt.xticks(tick_marks, target_names, rotation=45)
        plt.yticks(tick_marks, target_names)

    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]


    thresh = cm.max() / 1.5 if normalize else cm.max() / 2
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        if normalize:
            plt.text(j, i, "{:0.4f}".format(cm[i, j]),
                     horizontalalignment="center",
                     color="white" if cm[i, j] > thresh else "black")
        else:
            plt.text(j, i, "{:,}".format(cm[i, j]),
                     horizontalalignment="center",
                     color="white" if cm[i, j] > thresh else "black")


    plt.tight_layout()
    plt.ylabel('True label')
    plt.xlabel('Predicted label\naccuracy={:0.4f}; misclass={:0.4f}'.format(accuracy, misclass))
    plt.show()