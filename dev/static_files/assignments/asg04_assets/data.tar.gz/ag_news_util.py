import subprocess
import pandas as pd
from collections import Counter
from keras.preprocessing.sequence import pad_sequences
import random

PAD_TOK = '<pad>'
UNK_TOK = '<unk>'

special_toks = [PAD_TOK,UNK_TOK]

AG_NEWS_LBLS = ['World', 'Sports', 'Business', 'Sci/Tech']

AG_NEWS_URL = "https://iust-deep-learning.github.io/972/static_files/assignments/asg04_assets/ag_news_csv.tar.gz"

def read_split(fname):
  p = pd.read_csv(fname, header=None)
  lst = [tuple(x) for x in p.to_records(index=False)]
  lst = [(s.replace('\\', ' '), l) for l,_,s in lst]
  random.shuffle(lst)
  random.shuffle(lst)
  sents, lbls = zip(*lst)
  del p
  del lst
  
  return sents, [l-1 for l in lbls]

def read_ag_news():
  subprocess.run(('wget %s'%AG_NEWS_URL).split(' '))
  subprocess.run(('tar xvfz ag_news_csv.tar.gz').split(' '))
  
  x_train, y_train = read_split('ag_news_csv/train.csv')
  
  x_valid, y_valid = x_train[110000:], y_train[110000:]
  x_train, y_train = x_train[:110000], y_train[:110000]
  
  return (x_train, y_train), (x_valid, y_valid)

def create_vocab(lst, vocab_size):
  c = Counter()
  for s in lst:
    s = s.split(' ')
    c.update(s)
  
  words = [w for w,_ in c.most_common(vocab_size)] 
  vocab = special_toks + words
  
  return vocab
  
def create_model_input(lst, tok2id, maxlen):
  unk_id = tok2id[UNK_TOK]
  tok_ids = [[tok2id.get(w, unk_id) for w in s.split(' ')] for s in lst]
  input_ = pad_sequences(tok_ids, maxlen, dtype='int64', padding='post', truncating='post')
  del tok_ids
  return input_