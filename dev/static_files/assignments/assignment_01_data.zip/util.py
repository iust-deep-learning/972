import struct
import numpy as np

from keras.models import Model
from keras.layers import Lambda
from keras.datasets import imdb

def read_raw_dataset(file_name):
    with open(file_name, 'rb') as binary_file:
        data = binary_file.read()
        offset = 0
        
        # read private header
        yy = struct.unpack_from('H', data, offset)[0]
        offset += 2

        m = struct.unpack_from('B', data, offset)[0]
        offset += 1

        d = struct.unpack_from('B', data, offset)[0]
        offset += 1

        H = struct.unpack_from('B', data, offset)[0]
        offset += 1

        W = struct.unpack_from('B', data, offset)[0]
        offset += 1

        TotalRec = struct.unpack_from('I', data, offset)[0]
        offset += 4

        LetterCount = struct.unpack_from('128I', data, offset)
        offset += 128 * 4

        imgType = struct.unpack_from('B', data, offset)[0]  # 0: binary, 1: gray
        offset += 1

        Comments = struct.unpack_from('256c', data, offset)
        offset += 256 * 1

        Reserved = struct.unpack_from('245c', data, offset)
        offset += 245 * 1

        if (W > 0) and (H > 0):
            normal = True
        else:
            normal = False

        images = []
        labels = []

        for i in range(TotalRec):

            StartByte = struct.unpack_from('B', data, offset)[0]  # must be 0xff
            offset += 1

            label = struct.unpack_from('B', data, offset)[0]
            offset += 1

            if not normal:
                W = struct.unpack_from('B', data, offset)[0]
                offset += 1

                H = struct.unpack_from('B', data, offset)[0]
                offset += 1

            ByteCount = struct.unpack_from('H', data, offset)[0]
            offset += 2

            image = np.zeros(shape=[H, W], dtype=np.uint8)

            if imgType == 0:
                # Binary
                for y in range(H):
                    bWhite = True
                    counter = 0
                    while counter < W:
                        WBcount = struct.unpack_from('B', data, offset)[0]
                        offset += 1
                        # x = 0
                        # while x < WBcount:
                        #     if bWhite:
                        #         image[y, x + counter] = 0  # Background
                        #     else:
                        #         image[y, x + counter] = 255  # ForeGround
                        #     x += 1
                        if bWhite:
                            image[y, counter:counter + WBcount] = 0  # Background
                        else:
                            image[y, counter:counter + WBcount] = 255  # ForeGround
                        bWhite = not bWhite  # black white black white ...
                        counter += WBcount
            else:
                # GrayScale mode
                print(len(images))
                data = struct.unpack_from('{}B'.format(W * H), data, offset)
                offset += W * H
                image = np.asarray(data, dtype=np.uint8).reshape([W, H]).T

            images.append(image)
            labels.append(label)

        return images, labels

class BaseModel(Model):
  def __init__(self, *args, **kwargs):
    super().__init__(*args, **kwargs)
    self._trainable_weights = []

  @property
  def trainable_weights(self):
      return self._trainable_weights

  def call(self, x):
      return Lambda(self.build_model)(x)
    
def load_imdb_dataset():
  (train_data, train_labels), (test_data, test_labels) =  imdb.load_data(num_words=10000)
  word_index = imdb.get_word_index()
  reverse_word_index = dict([(value, key) for 
                             (key, value) in word_index.items()])
  decoded_review = ' '.join([reverse_word_index.get(i - 3, '?') 
                             for i in train_data[0]])
  
  def vectorize_sequences(sequences, dimension=10000):
    results = np.zeros((len(sequences), dimension))
    for i, sequence in enumerate(sequences):
        results[i, sequence] = 1.
    return results

  x_train = vectorize_sequences(train_data)
  x_test = vectorize_sequences(test_data)
  
  y_train = np.asarray(train_labels).astype('float32')
  y_test = np.asarray(test_labels).astype('float32')
  
  x_val = x_train[:10000]
  x_train = x_train[10000:]
  y_val = y_train[:10000]
  y_train = y_train[10000:]
  
  return (x_train, y_train), (x_val, y_val), (x_test, y_test)