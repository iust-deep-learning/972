import pickle

def load_potg_dataset():
  train = pickle.load(open('train.pkl', 'rb'))
  valid = pickle.load(open('valid.pkl', 'rb'))
  
  return train, valid